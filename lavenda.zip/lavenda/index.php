<html>
<head>
<title>Nyamuk</title>
<link rel="stylesheet" type="text/css" href="support/bootstrap/css/bootstrap.min.css">
<script type="text/javascript" src="support/jquery/jquery-2.1.4.min.js"></script>
</head>
<body>

<div class="container">
	<div class="row">
		<?php
		for($i = 1; $i<=16; $i++){
			echo '<div class="blocks col-sm-3">';

			echo '</div>';
		}
		?>
	</div>
</div>

</body>
</html>
<script type="text/javascript">
$(document).ready(function(){



	function panggil_nyamuk(level){
		var arr = [];
		// var level = 10;


		//Isi
		for(var i = 1; i <=16; i++){
			if(i <= level){  
				arr.push('1');
			}else{
				arr.push('0');
			}
		}


		//Function
		function Shuffle(o) {
			for(var j, x, i = o.length; i; j = parseInt(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
			return o;
		};


		//Shuffle
		Shuffle(arr);


		//Isi nyamuk
		for(i = 1; i <= arr.length; i++){
			var nyamuk = '0';
			
			if(arr[i] == '1'){
				nyamuk = '1';
			}
			
		  	$('.blocks').eq(i-1).html(nyamuk);
		}
	}


	//Run
	panggil_nyamuk(1);


});
</script>