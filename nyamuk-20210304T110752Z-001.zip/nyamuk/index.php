<html>
<head>
<title>Nyamuk</title>
<link rel="stylesheet" type="text/css" href="support/bootstrap/css/bootstrap.min.css">
<script type="text/javascript" src="support/jquery/jquery-2.1.4.min.js"></script>
<style type="text/css">
.hased{
	background-color: red !important;
}
.blocks{
    border: 1px solid;
    /*height: 45px;*/
    text-align: center;
    padding: 5px;
    height: 20%;
    z-index: 2;
}
.container {
    cursor: url("squash_racket1.gif"), auto;
}
.relatif{
    position: relative;
     /*display: none;*/ 
    width: 100%;
    height: 100%;
    display: block;
}
.score{
	position: absolute;
    top: 50%;
    left: 50%;
    display: none;
    text-align: center;
    	font-size: 63px;
    color: blue;
        transform: translate(-50%,-50%);
}
#scoredd{
	font-size: 63px;
    color: blue;
}
</style>
</head>
<body>

<div class="container">
	<div class="row">
		<?php
		for($i = 1; $i<=16; $i++){
			echo '<div class="blocks col-sm-3">';
			
			echo '</div>';
		}
		// echo '<div class="relatif">
		// 			<div class="score">
		// 				<div class>
		// 					"Your Score"
		// 				</div>
		// 				<div id="scoredd">
		// 					0
		// 				</div>
		// 			</div>
		// 		  </div>';
		?>
	</div>
	<div class="row">
		<input type="text" class="valdata" value="">
	</div>
</div>

</body>
</html>
<script type="text/javascript">
$(document).ready(function(){

	var level = 0;
	var value = 0;

	var load = function(){
		if(level <= 9){
			//$('.blocks span').load('index.php');
		
		
			level = level+1;
			panggil_nyamuk(level);
			console.log(level);
			//$('.blocks span').fadeOut();
			setTimeout(function(event){
				$('.blocks span').fadeOut();
				setTimeout(load,2000);
			},2000);
		}else{
			return;
		}	
	}

	load();

	function panggil_nyamuk(level){
		var arr = [];
		// var level = 10;


		//Isi
		for(var i = 1; i <=16; i++){
			if(i <= level){  
				arr.push('1');
			}else{
				arr.push('0');
			}
		}


		// Function
		// function Shuffle(o) {
		// 	for(var j, x, i = o.length; i; j = parseInt(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
		// 	return o;
		// };
		arr.sort(function() { return 0.5 - Math.random() });

		//Shuffle
		//Shuffle(arr);


		//Isi nyamuk
		for(i = 0; i <= arr.length; i++){
			var nyamuk = '0';
			
			if(arr[i] == '1'){
				nyamuk = '<span class="active'+i+'" style="background-color:blue;font-weight:bold;color:#fff;padding:5px;display: block;height: 100%;">ada nyamuk</span>';
			}
			else{
				nyamuk = '';
			}
			
		  	$('.blocks').eq(i).html(nyamuk);
		  	
		  	$('span.active'+i).click(function(){
		  		//if('span.active'+i).has('hased')
		  		$(this).addClass('hased');
		  		value = value+1;
		  		$('input.valdata').val(value);
		  		
		  		$('#scoredd').text(value);

		  		$(this).hide();
		  	});
		}

	}
});
</script>